DESCRIBE salgrade;
SELECT * FROM salgrade;
CREATE VIEW SALARY_VU ('Employee','Department','Salary','Grade') AS 
 SELECT emp.ename,emp.deptno,emp.sal, 
	CASE WHEN emp.sal BETWEEN (SELECT salgrade.LOSAL FROM salgrade LIMIT 1 OFFSET 0) AND (SELECT salgrade.HISAL FROM salgrade LIMIT 1 OFFSET 0) THEN (SELECT salgrade.grade FROM salgrade LIMIT 1 OFFSET 0) END
	CASE WHEN emp.sal BETWEEN (SELECT salgrade.LOSAL FROM salgrade LIMIT 1 OFFSET 1) AND (SELECT salgrade.HISAL FROM salgrade LIMIT 1 OFFSET 1) THEN (SELECT salgrade.grade FROM salgrade LIMIT 1 OFFSET 1) END
	CASE WHEN emp.sal BETWEEN (SELECT salgrade.LOSAL FROM salgrade LIMIT 1 OFFSET 2) AND (SELECT salgrade.HISAL FROM salgrade LIMIT 1 OFFSET 2) THEN (SELECT salgrade.grade FROM salgrade LIMIT 1 OFFSET 0) END
	CASE WHEN emp.sal BETWEEN (SELECT salgrade.LOSAL FROM salgrade LIMIT 1 OFFSET 0) AND (SELECT salgrade.HISAL FROM salgrade LIMIT 1 OFFSET 0) THEN (SELECT salgrade.grade FROM salgrade LIMIT 1 OFFSET 0) END
	CASE WHEN emp.sal BETWEEN (SELECT salgrade.LOSAL FROM salgrade LIMIT 1 OFFSET 0) AND (SELECT salgrade.HISAL FROM salgrade LIMIT 1 OFFSET 0) THEN (SELECT salgrade.grade FROM salgrade LIMIT 1 OFFSET 0) END
    