# 1.
SELECT CURDATE() '系統日期';

# 2.
SELECT empno,ename,sal, ROUND(sal*1.15,0) 'New Salary' FROM emp;

# 3.
SELECT empno,ename,sal, ROUND(sal*1.15,0) 'New Salary' FROM emp;

# 4.
SELECT ename,hiredate, 
	DATE_FORMAT(
				ADDDATE(
					ADDDATE(hiredate, INTERVAL 6 MONTH), 
					( ( 7 - (WEEKDAY(ADDDATE(hiredate, INTERVAL 6 MONTH ) ) ) ) MOD 7 )
				)
				,'%W, the %D of %M') 'REVIEW' FROM emp;

# 5.
SELECT ename, ROUND(DATEDIFF(NOW(),hiredate)/30,0) 'MONTHS_WORKED' FROM emp;

# 6. 
SELECT CONCAT(ename,' earns ',sal, ' monthly but wants ',3*sal) 'Dream Salaries' FROM emp;

# 7.
SELECT ename, LPAD(sal,15,'$') 'SALARY' FROM emp;

# 8.
SELECT ename, hiredate, (WEEKDAY(hiredate) + 1) 'DAY' FROM emp ORDER BY (WEEKDAY(hiredate) + 1) ASC;

# 9. 
SELECT ename, IFNULL(comm,'No Commision') 'COMM' FROM emp;

# 10.
SELECT CONCAT(ename,' ',REPEAT('*',ROUND(sal/100,0))) 'EMPLOYEE_AND_THEIR_SALARIES' FROM emp ORDER By sal DESC;
