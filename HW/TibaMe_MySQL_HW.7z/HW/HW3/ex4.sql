SELECT ename,hiredate, 
	DATE_FORMAT(
				ADDDATE(
					ADDDATE(hiredate, INTERVAL 6 MONTH), 
					( ( 7 - (WEEKDAY(ADDDATE(hiredate, INTERVAL 6 MONTH ) ) ) ) MOD 7 )
				)
				,'%W, the %D of %M') 'REVIEW' FROM emp;