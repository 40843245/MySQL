# 1. 
SELECT 	ename,hiredate FROM emp WHERE deptno IN (SELECT deptno FROM emp WHERE ename='BLAKE');

# 2. 
SELECT ename,hiredate FROM emp WHERE hiredate >=(SELECT hiredate FROM emp WHERE ename='BLAKE');

# 3.
SELECT empno,ename,sal FROM emp WHERE sal >= (SELECT AVG(sal) FROM emp) ORDER BY sal DESC ;

# 4.
SELECT empno,ename FROM emp WHERE deptno IN (SELECT deptno FROM emp WHERE ename LIKE '%T%');

# 5.
SELECT emp.ename, dept.deptno, emp.job FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno) WHERE loc = 'DALLAS';

# 6. 
SELECT ename,sal FROM emp WHERE mgr = (SELECT empno FROM emp WHERE ename = 'King');	

# 7. 
SELECT emp.deptno, emp.ename,emp.job FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE emp.deptno = (SELECT dept.deptno FROM dept WHERE dname = 'Sales') ;

# 8. 
SELECT empno, ename,sal FROM emp WHERE ( sal >= (SELECT AVG(sal) FROM emp) ) AND ( deptno IN (SELECT deptno FROM emp WHERE ename LIKE '%T%' ) );

# 9.
SELECT ename,deptno,sal,comm FROM emp WHERE ( 
	( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) ) AND
    (comm IS NOT NULL)
);

# 10.
SELECT 	emp.ename,emp.deptno,emp.sal FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE (
	( emp.deptno IN (SELECT dept.deptno FROM dept WHERE loc = 'Dallas') ) AND 
    ( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) )
);

# 11.
SELECT ename,hiredate,sal FROM emp WHERE (
	ename != 'Scott' AND
	( sal IN(SELECT sal FROM emp WHERE ename = 'Scott') ) AND
    ( IFNULL(comm,0) IN(SELECT IFNULL(comm,0) FROM emp WHERE ename = 'Scott') ) 
);


# 12.
SELECT ename, hiredate,sal FROM emp WHERE sal > (SELECT MAX(sal) FROM emp WHERE job = 'Clerk') ORDER BY sal DESC;