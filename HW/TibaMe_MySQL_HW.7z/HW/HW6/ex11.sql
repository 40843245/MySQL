SELECT ename,hiredate,sal FROM emp WHERE (
	ename != 'Scott' AND
	( sal IN(SELECT sal FROM emp WHERE ename = 'Scott') ) AND
    ( IFNULL(comm,0) IN(SELECT IFNULL(comm,0) FROM emp WHERE ename = 'Scott') ) 
);