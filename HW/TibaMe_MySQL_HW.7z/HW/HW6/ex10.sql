SELECT 	emp.ename,emp.deptno,emp.sal FROM ( emp INNER JOIN dept ON emp.deptno = dept.deptno ) WHERE (
	( emp.deptno IN (SELECT dept.deptno FROM dept WHERE loc = 'Dallas') ) AND 
    ( sal IN (SELECT sal FROM emp GROUP BY sal HAVING COUNT(sal) > 1) )
);