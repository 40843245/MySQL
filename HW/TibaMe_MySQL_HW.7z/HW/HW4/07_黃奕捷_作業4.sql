# 1. 
SELECT ROUND(MAX(sal),0) 'Maximum', ROUND(MIN(sal),0) 'Minimum', ROUND(SUM(sal),0) 'Sum', ROUND(AVG(sal),0) 'Average' FROM emp;

# 2.
SELECT MIN(sal),MAX(sal),SUM(sal),AVG(sal) FROM emp GROUP BY job;

# 3.
SELECT COUNT(ename) FROM emp GROUP BY job;

# 4. 
SELECT COUNT(mgr) 'Number of Managers' FROM (SELECT mgr  FROM emp WHERE mgr IS NOT NULL GROUP BY mgr) AS derivedTable1;

# 5.
SELECT (MAX(sal)-MIN(sal)) 'DIFFERENCE' FROM emp;

# 6.
SELECT mgr,MIN(sal) FROM emp GROUP BY mgr HAVING mgr IS NOT NULL AND MIN(sal) >= 1000 ORDER BY MIN(sal) DESC;

# 7. 
SELECT YEAR(hiredate),COUNT(ename) 'Number of People' FROM emp WHERE YEAR(hiredate) in (2011,2013) GROUP BY YEAR(hiredate);