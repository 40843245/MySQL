START TRANSACTION;
UPDATE my_emp SET salary = salary * 1.1;
SAVEPOINT TX1;
SET SQL_SAFE_UPDATES = 0; -- disable safe operating when updating or deleting.
DELETE FROM my_emp WHERE 1; -- delete all rows from `my_emp` table.
SAVEPOINT TX2;
SELECT * FROM my_emp; -- select all rows from `my_emp` table.
SAVEPOINT TX3;

ROLLBACK TO TX3;
ROLLBACK TO TX2;
ROLLBACK TO TX1;

ROLLBACK;