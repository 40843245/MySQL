# 1.
SELECT ename, emp.deptno , dname, loc FROM emp INNER JOIN dept ON emp.deptno = dept.deptno;

# 2.
SELECT ename, comm , dname, loc FROM emp INNER JOIN dept ON emp.deptno = dept.deptno WHERE comm IS NOT NULL AND comm > 0 ;

# 3. 
SELECT ename, dname FROM emp INNER JOIN dept ON emp.deptno = dept.deptno WHERE ename LIKE '%A%';

# 4. 
SELECT ename,job,emp.deptno,dname FROM emp INNER JOIN dept ON emp.deptno = dept.deptno WHERE loc = "DALLAS";

# 5.
SELECT e1.ename 'Employee', e1.empno 'Emp#',e2.ename 'Manager',e1.mgr 'Mgr#' FROM emp e1 INNER JOIN emp e2 ON e1.mgr = e2.empno;

# 6. 
DESCRIBE salgrade;
SELECT emp.ename,emp.job,dept.dname,emp.sal,salgrade.grade FROM ( ( emp INNER JOIN salgrade ON emp.sal BETWEEN salgrade.losal AND salgrade.hisal ) INNER JOIN dept ON emp.deptno = dept.deptno) ;

# 7.
SELECT e1.ename 'Employee', e1.hiredate 'Emp Hiredate', e2.ename 'Manager', e2.hiredate 'Mgr Hiredate'
FROM (emp e1 INNER JOIN emp e2 ON e1.mgr = e2.empno) 
WHERE e1.hiredate <= e2.hiredate;

# 8.
SELECT dname, loc,COUNT(ename) 'Number of People',ROUND(AVG(sal),2) 'Salary' FROM emp INNER JOIN dept ON emp.deptno = dept.deptno GROUP BY dept.deptno;

# 9.
SELECT dept.deptno, dept.dname,COUNT(emp.ename) 'Emp#' FROM emp RIGHT OUTER JOIN dept ON emp.deptno = dept.deptno GROUP BY dept.deptno;