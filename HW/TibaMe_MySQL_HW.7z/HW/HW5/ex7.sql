SELECT e1.ename 'Employee', e1.hiredate 'Emp Hiredate', e2.ename 'Manager', e2.hiredate 'Mgr Hiredate'
FROM (emp e1 INNER JOIN emp e2 ON e1.mgr = e2.empno) 
WHERE e1.hiredate <= e2.hiredate;